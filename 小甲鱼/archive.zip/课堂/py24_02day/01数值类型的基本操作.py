"""
============================
Author:柠檬班-木森
Time:2019/10/21
E-mail:3247119728@qq.com
Company:湖南零檬信息技术有限公司
============================
"""

"""
数值类型的数据
整数：int（整数类型）
小数：float(浮点类型)
布尔值：bool（一种特殊的数值类型）:只有True 和False两个值

复数（不学）


type：内置函数，可以用来查看数据的类型

"""

#  整数
# number1 = 100
# a = 20
# res = type(a)
# print(res)

# 浮点数
# b = 1.2
# c = 222.2
# res2 = type(b)
# print(res2)

# 布尔类型数据
# t = True
# f = False
# res3 = type(f)
# print(res3)


# python中的运算符

# 算术运算符
"""
+ :加
- :减
* ：乘
/ ：除
** :幂运算
% :取余
//:除法取整（取商）
"""
# a = 20
# b = 5
# res = a / b
# print(res)
# print(2**4)
# print(9//5)

# 赋值运算符: =  +=  -=  *=  /=  %=
# aa = 22
# # aa = aa + 1    # 等同于  aa +=1
# aa -= 1  # 等同于 aa = aa-1
# print(aa)

# 比较运算符
# 比较的条件成立，返回的是True,条件不成立返回的是False
"""
==   表示等于
！=  表示不等于

"""

# a1 = 12
# b1 = 12
# print(a1 > b1)
# print(111 == 111)
# print("musen" == "xiaoming")

#  逻辑运算符： 与  或  非
"""
and: 真真为真（所有的条件都要成立,才会返回True,否则返回False）
or : 一真为真，假假为假(只要有一个以上的条件成立，就返回True,都不成立返回False)
not: 取反
"""


# print(10 < 8 or 9 > 10)
# print(not 10 < 7)

# 运算符的优先级：用括号解决
# print(10 > 8 and (11 > 19 or 11 < 19))
