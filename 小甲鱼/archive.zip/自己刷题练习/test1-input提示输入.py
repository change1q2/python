from fileinput import input
print('*'*10)
name=input("请输入姓名:")#提示输入
sex=input("请输入性别:")
age=input("请输入年龄:")
print('*'*10)
print('姓名:'+name)
print('性别:'+sex)
print('年龄:'+age)
print('*'*10)
